package pl.pearlalert;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class PearlAlertScreen extends Screen {

    private ButtonWidget hudButton;
    private ButtonWidget ownButton;

    public PearlAlertScreen() {
        super(Text.literal("Pearl Alert"));
    }

    @Override
    protected void init() {
        int cx = width / 2;

        hudButton = ButtonWidget.builder(hudLabel(), b -> {
            PearlAlertClient.hudEnabled = !PearlAlertClient.hudEnabled;
            b.setMessage(hudLabel());
        }).dimensions(cx - 100, 40, 200, 20).build();

        ownButton = ButtonWidget.builder(ownLabel(), b -> {
            PearlAlertClient.showOwn = !PearlAlertClient.showOwn;
            b.setMessage(ownLabel());
        }).dimensions(cx - 100, 64, 200, 20).build();

        addDrawableChild(hudButton);
        addDrawableChild(ownButton);

        addDrawableChild(ButtonWidget.builder(Text.literal("Wyczyść historię"), b ->
                PearlAlertClient.HISTORY.clear()
        ).dimensions(cx - 100, 88, 200, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Zamknij"), b -> close())
                .dimensions(cx - 100, height - 30, 200, 20).build());
    }

    private Text hudLabel() {
        return Text.literal("Powiadomienia na ekranie: " + (PearlAlertClient.hudEnabled ? "§aWŁ" : "§cWYŁ"));
    }

    private Text ownLabel() {
        return Text.literal("Pokazuj moje perły: " + (PearlAlertClient.showOwn ? "§aTAK" : "§cNIE"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        int cx = width / 2;
        context.drawCenteredTextWithShadow(textRenderer, title, cx, 20, 0xFFFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer, Text.literal("Historia rzuconych pereł:"), cx, 118, 0xFFAAAAAA);

        long now = System.currentTimeMillis();
        int y = 132;
        var list = PearlAlertClient.HISTORY;
        if (list.isEmpty()) {
            context.drawCenteredTextWithShadow(textRenderer, Text.literal("(brak)"), cx, y, 0xFF777777);
            return;
        }
        for (int i = list.size() - 1; i >= 0 && y < height - 45; i--) {
            var e = list.get(i);
            long sec = (now - e.time()) / 1000;
            String line = e.name() + " – " + Math.round(e.distance()) + " m – "
                    + String.format("XYZ %.0f %.0f %.0f", e.x(), e.y(), e.z()) + " – " + sec + "s temu";
            context.drawCenteredTextWithShadow(textRenderer, Text.literal(line), cx, y, 0xFFFFFFFF);
            y += 11;
        }
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
