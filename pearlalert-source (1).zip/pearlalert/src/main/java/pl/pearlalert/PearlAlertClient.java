package pl.pearlalert;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientEntityEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.thrown.EnderPearlEntity;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class PearlAlertClient implements ClientModInitializer {

    public record PearlEvent(String name, double distance, double x, double y, double z, long time) {}

    public static final List<PearlEvent> HISTORY = new ArrayList<>();
    public static boolean hudEnabled = true;
    public static boolean showOwn = false;
    public static final long HUD_DURATION_MS = 6000;

    private static KeyBinding openGuiKey;

    @Override
    public void onInitializeClient() {
        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.pearlalert.gui",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_L,
                "category.pearlalert"
        ));

        // Wykrywanie rzuconej perły (encja pojawia się u klienta)
        ClientEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            if (entity instanceof EnderPearlEntity pearl) {
                handlePearl(pearl);
            }
        });

        // Klawisz L -> GUI
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openGuiKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new PearlAlertScreen());
                }
            }
        });

        // Napisy na ekranie (HUD)
        HudRenderCallback.EVENT.register((context, tickCounter) -> {
            if (!hudEnabled) return;
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.options.hudHidden) return;

            long now = System.currentTimeMillis();
            int y = 30;
            int x = context.getScaledWindowWidth() / 2;
            for (int i = HISTORY.size() - 1; i >= 0 && y < 30 + 5 * 12; i--) {
                PearlEvent e = HISTORY.get(i);
                if (now - e.time() > HUD_DURATION_MS) break;
                Text t = Text.literal("⚠ " + e.name() + " rzucił perłę! (" + Math.round(e.distance()) + " m)");
                context.drawCenteredTextWithShadow(mc.textRenderer, t, x, y, 0xFFAA55FF);
                y += 12;
            }
        });
    }

    private static void handlePearl(EnderPearlEntity pearl) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        Entity owner = pearl.getOwner();
        boolean own = owner != null && owner == mc.player;
        if (own && !showOwn) return;

        String name = owner != null ? owner.getName().getString() : "Ktoś";
        double dist = mc.player.distanceTo(pearl);
        HISTORY.add(new PearlEvent(name, dist, pearl.getX(), pearl.getY(), pearl.getZ(), System.currentTimeMillis()));
        if (HISTORY.size() > 50) HISTORY.remove(0);

        // Dodatkowo napis nad hotbarem
        if (hudEnabled) {
            mc.inGameHud.setOverlayMessage(Text.literal("§d" + name + " §fRZUCIŁ PERŁĘ!"), false);
        }
    }
}
